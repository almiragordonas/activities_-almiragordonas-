/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class Mod01_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         int c[] = {11, 20, 60,10,99}; 
        int t[] = new int[c.length];
        t=c;
        System.out.println(" array a[] is:  "); 
        for (int i=0; i<c.length; i++) 
        System.out.print(c[i]+" "); 
        System.out.println("\n\n array b[] is: "); 
        for (int i=0; i<t.length; i++) 
        System.out.print(t[i] + " "); 
    
    }
    
}
