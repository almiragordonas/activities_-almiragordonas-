/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class Mod01_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         String ag ="the quick brown fox";
        String agg ="queen";
  System.out.println("the given string is: "+ag);
  System.out.println("the given mask string is: "+agg+"\n");
  
 System.out.println("the new string is: "+ag.replace("e","").replace("n", "").replace("qu", ""));
            
       
    }
    
}
