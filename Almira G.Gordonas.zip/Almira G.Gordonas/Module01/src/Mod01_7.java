
import java.io.File;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class Mod01_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         File files = new File("C:\\Users\\hp\\Documents\\GitHub");
      if (files.exists()) {
    
     String contents[] = files.list();
      System.out.println("List of file/directory is: ");
      for(int i=0; i<contents.length; i++) 
         System.out.println(contents[i]);
        }else{
          System.out.println("file does not exist.\n");
      }
    }
    
}
